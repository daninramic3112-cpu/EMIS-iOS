import SwiftUI

@main struct EMISApp: App {
    @StateObject private var store = EMISStore()
    var body: some Scene { WindowGroup { RootView().environmentObject(store).preferredColorScheme(.light) } }
}

struct Student: Codable, Identifiable {
    var id: String { username }
    let username: String
    var name: String
    var classroom: String
    var grades: [String:[Int]] = [:]
    var comments: [String] = []
    var absences: Int = 0
}
struct Lesson: Codable, Identifiable {
    var id = UUID()
    var date: String; var classroom: String; var subject: String; var number: String
    var kind: String; var topic: String; var homework: String; var note: String; var teacher: String
}
struct EMISData: Codable { var students: [Student]; var lessons: [Lesson] = [] }

@MainActor final class EMISStore: ObservableObject {
    @Published var data: EMISData
    @Published var user = ""
    @Published var isTeacher = false
    @Published var loggedIn = false
    @Published var message = ""
    let classes = (1...9).flatMap { n in ["\(roman(n))-1", "\(roman(n))-2"] }
    let subjects = ["Bosanski jezik","Matematika","Engleski jezik","Njemački jezik","Historija","Geografija","Biologija","Fizika","Hemija","Informatika","Likovna kultura","Muzička kultura","Tjelesni odgoj","Tehnička kultura","Vjeronauka"]
    private var fileURL: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("emis_database.json") }
    init() {
        if let bytes = try? Data(contentsOf: fileURL), let saved = try? JSONDecoder().decode(EMISData.self, from: bytes) { data = saved }
        else { data = EMISData(students: Self.makeStudents()) }
    }
    static func makeStudents() -> [Student] {
        let first = ["Amar","Adnan","Haris","Emir","Tarik","Dino","Emin","Armin","Kerim","Anes","Nedim","Aldin","Mirza","Hamza","Ahmed","Faruk","Faris","Imran","Ajdin","Benjamin","Alen","Eldar","Edin","Jasmin","Samir","Kenan","Mahir","Nermin","Amina","Lejla","Sara","Hana","Emina","Lamija","Merjem","Ajla","Džana","Iman","Esma","Nejla","Belma","Amna","Dina","Mia","Una","Nina","Elma","Selma","Alma","Melisa","Azra","Ena","Iva","Tea","Matea","Anja","Lana","Nora","Mina","Nika","Lara","Maja","Ema","Džejla","Asja","Naida","Zara","Sumeja","Irma","Sabina","Amela","Adna"]
        let last = ["Hodžić","Kovačević","Hadžić","Begić","Mujkić","Delić","Halilović","Alić","Osmanović","Jukić","Mešić","Avdić","Imamović","Hasanović","Čengić","Šabić","Ramić","Salihović","Hasić","Zukić","Karić","Muratović","Smajić","Bašić","Bešić","Omerović","Šehić","Čaušević","Pašić","Krupić"]
        return (0..<450).map { i in Student(username: String(format:"U%04d",i+1), name:"\(first[i % first.count]) \(last[(i*7) % last.count]) \(i+1)", classroom:"\(roman(i/50+1))-\((i%50)/25+1)") }
    }
    func login(_ name:String,_ password:String) {
        if name == "Danin" && password == "rsjebosna" { user=name; isTeacher=true; loggedIn=true; return }
        if password == "skola123" && data.students.contains(where:{$0.username == name}) { user=name; isTeacher=false; loggedIn=true; return }
        message="Pogrešno korisničko ime ili lozinka."
    }
    func logout(){loggedIn=false;user="";isTeacher=false}
    var currentStudent: Student? { data.students.first{$0.username == user} }
    var totalAbsences:Int { data.students.reduce(0){$0+$1.absences} }
    func save(){do{try JSONEncoder().encode(data).write(to:fileURL,options:.atomic)}catch{message="Greška pri čuvanju: \(error.localizedDescription)"}}
    func addLesson(_ l:Lesson){data.lessons.append(l);save()}
    func addGrade(_ id:String,_ subject:String,_ grade:Int){guard let i=data.students.firstIndex(where:{$0.username==id}) else{return};data.students[i].grades[subject,default:[]].append(grade);save()}
    func addAbsence(_ id:String){guard let i=data.students.firstIndex(where:{$0.username==id}) else{return};data.students[i].absences += 1;save()}
    func addComment(_ id:String,_ comment:String){guard let i=data.students.firstIndex(where:{$0.username==id}) else{return};data.students[i].comments.append(comment);save()}
}
func roman(_ n:Int)->String{["I","II","III","IV","V","VI","VII","VIII","IX"][max(0,min(8,n-1))]}

struct RootView: View {
    @EnvironmentObject var store:EMISStore
    var body:some View { Group{if store.loggedIn{MainView()}else{LoginView()}}.tint(.blue).alert("EMIS",isPresented:Binding(get:{!store.message.isEmpty},set:{if !$0{store.message=""}})){Button("U redu"){store.message=""}}message:{Text(store.message)} }
}
struct LoginView:View{
    @EnvironmentObject var store:EMISStore;@State private var username="";@State private var password=""
    var body:some View{ZStack{LinearGradient(colors:[Color(red:0.07,green:0.15,blue:0.29),Color(red:0.12,green:0.34,blue:0.59)],startPoint:.topLeading,endPoint:.bottomTrailing).ignoresSafeArea();VStack(spacing:24){Image(systemName:"graduationcap.fill").font(.system(size:48)).foregroundStyle(.white);VStack(spacing:5){Text("EMIS").font(.system(size:36,weight:.bold,design:.rounded)).foregroundStyle(.white);Text("ELEKTRONSKI DNEVNIK").font(.caption.bold()).tracking(2).foregroundStyle(.white.opacity(0.8))};VStack(spacing:14){TextField("Korisničko ime",text:$username).textInputAutocapitalization(.never).autocorrectionDisabled().padding().background(.white).clipShape(RoundedRectangle(cornerRadius:13));SecureField("Lozinka",text:$password).padding().background(.white).clipShape(RoundedRectangle(cornerRadius:13));Button("Prijavi se"){store.login(username.trimmingCharacters(in:.whitespaces),password)}.fontWeight(.bold).frame(maxWidth:.infinity).padding().background(.white).foregroundStyle(.blue).clipShape(RoundedRectangle(cornerRadius:13))}.padding(22).background(.white.opacity(0.13)).clipShape(RoundedRectangle(cornerRadius:20));Text("Demo nastavnik: Danin  •  Demo učenik: U0001").font(.footnote).foregroundStyle(.white.opacity(0.8))}.padding(26)}}
}
struct MainView:View{
    @EnvironmentObject var store:EMISStore
    var body:some View{TabView{DashboardView().tabItem{Label("Početna",systemImage:"house.fill")};if store.isTeacher{StudentsView().tabItem{Label("Učenici",systemImage:"person.3.fill")};LessonsView().tabItem{Label("Časovi",systemImage:"book.fill")};TeacherActionsView().tabItem{Label("Evidencija",systemImage:"square.and.pencil")}}else{StudentDetailsView().tabItem{Label("Moji podaci",systemImage:"person.fill")}}}}
}
struct MetricCard:View{let title:String;let value:String;let icon:String;var body:some View{VStack(alignment:.leading,spacing:12){Image(systemName:icon).font(.title2).foregroundStyle(.blue);Text(value).font(.system(size:28,weight:.bold));Text(title).font(.subheadline).foregroundStyle(.secondary)}.padding().frame(maxWidth:.infinity,alignment:.leading).background(.white).clipShape(RoundedRectangle(cornerRadius:16))}}
struct DashboardView:View{
    @EnvironmentObject var store:EMISStore
    var body:some View{NavigationStack{ScrollView{VStack(alignment:.leading,spacing:18){VStack(alignment:.leading,spacing:5){Text("Dobro došli,").foregroundStyle(.secondary);Text(store.isTeacher ? "Nastavniče \(store.user)" : (store.currentStudent?.name ?? store.user)).font(.title2.bold())};if store.isTeacher{LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:12){MetricCard(title:"Učenici",value:"\(store.data.students.count)",icon:"person.3.fill");MetricCard(title:"Časovi",value:"\(store.data.lessons.count)",icon:"book.fill");MetricCard(title:"Izostanci",value:"\(store.totalAbsences)",icon:"calendar.badge.exclamationmark");MetricCard(title:"Odjeljenja",value:"18",icon:"building.2.fill")};VStack(alignment:.leading,spacing:14){Text("Brze radnje").font(.headline);NavigationLink("Upiši novi čas",systemImage:"plus.circle.fill"){AddLessonView()};NavigationLink("Upiši ocjenu",systemImage:"star.fill"){AddGradeView()};NavigationLink("Evidentiraj izostanak",systemImage:"calendar.badge.plus"){AddAbsenceView()};NavigationLink("Dodaj komentar",systemImage:"text.bubble"){AddCommentView()}}.padding().frame(maxWidth:.infinity,alignment:.leading).background(.white).clipShape(RoundedRectangle(cornerRadius:16))}else if let s=store.currentStudent{MetricCard(title:"Odjeljenje",value:s.classroom,icon:"building.2.fill");MetricCard(title:"Izostanci",value:"\(s.absences)",icon:"calendar.badge.exclamationmark");Text("Ocjene").font(.headline);ForEach(s.grades.keys.sorted(),id:\.self){subject in Text("\(subject): \((s.grades[subject] ?? []).map(String.init).joined(separator:", "))").padding().frame(maxWidth:.infinity,alignment:.leading).background(.white).clipShape(RoundedRectangle(cornerRadius:12))}}}.padding()}.background(Color(.systemGroupedBackground)).navigationTitle("EMIS").toolbar{ToolbarItem(placement:.topBarTrailing){Button("Odjava"){store.logout()}}}}}
}
struct StudentsView:View{
    @EnvironmentObject var store:EMISStore;@State private var search="";@State private var classroom="VII-2"
    var filtered:[Student]{store.data.students.filter{$0.classroom==classroom && (search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || $0.username.localizedCaseInsensitiveContains(search))}}
    var body:some View{NavigationStack{VStack{Picker("Odjeljenje",selection:$classroom){ForEach(store.classes,id:\.self){Text($0)}}.pickerStyle(.menu);List(filtered){s in NavigationLink{StudentProfileView(studentID:s.username)}label:{VStack(alignment:.leading){Text(s.name).fontWeight(.semibold);Text("\(s.username) • \(s.absences) izostanaka").font(.caption).foregroundStyle(.secondary)}}}}.searchable(text:$search,prompt:"Pretraži učenike").navigationTitle("Učenici")}}
}
struct StudentProfileView:View{
    @EnvironmentObject var store:EMISStore;let studentID:String;var student:Student?{store.data.students.first{$0.username==studentID}}
    var body:some View{List{if let s=student{Section("Podaci"){LabeledContent("Ime",value:s.name);LabeledContent("Korisničko ime",value:s.username);LabeledContent("Odjeljenje",value:s.classroom);LabeledContent("Izostanci",value:"\(s.absences)")};Section("Ocjene"){ForEach(s.grades.keys.sorted(),id:\.self){k in Text("\(k): \((s.grades[k] ?? []).map(String.init).joined(separator:", "))")}};Section("Komentari"){ForEach(Array(s.comments.enumerated()),id:\.offset){_,c in Text(c)}}}}.navigationTitle("Profil učenika")}
}
struct LessonsView: View {
    @EnvironmentObject var store: EMISStore
    var body: some View {
        NavigationStack {
            List {
                ForEach(store.data.lessons.reversed()) { lesson in
                    VStack(alignment: .leading, spacing: 5) {
                        Text(lesson.topic).fontWeight(.semibold)
                        Text("\(lesson.classroom) • \(lesson.subject) • \(lesson.date)").font(.caption).foregroundStyle(.secondary)
                        if !lesson.homework.isEmpty { Text("Domaća zadaća: \(lesson.homework)").font(.subheadline) }
                    }
                }
            }
            .navigationTitle("Evidencija časova")
            .toolbar { NavigationLink { AddLessonView() } label: { Image(systemName: "plus") } }
        }
    }
}
struct TeacherActionsView:View{var body:some View{NavigationStack{List{NavigationLink("Upiši ocjenu",systemImage:"star.fill"){AddGradeView()};NavigationLink("Evidentiraj izostanak",systemImage:"calendar.badge.plus"){AddAbsenceView()};NavigationLink("Dodaj komentar",systemImage:"text.bubble"){AddCommentView()}}.navigationTitle("Evidencija")}}}
struct AddLessonView:View{
    @EnvironmentObject var store:EMISStore;@Environment(\.dismiss) var dismiss
    @State private var classroom="VII-2";@State private var subject="Matematika";@State private var number="1";@State private var kind="Obrada";@State private var topic="";@State private var homework="";@State private var note=""
    var body:some View{Form{Section("Čas"){Picker("Odjeljenje",selection:$classroom){ForEach(store.classes,id:\.self){Text($0)}};Picker("Predmet",selection:$subject){ForEach(store.subjects,id:\.self){Text($0)}};TextField("Broj časa",text:$number).keyboardType(.numberPad);Picker("Tip časa",selection:$kind){ForEach(["Obrada","Utvrđivanje","Ponavljanje","Provjera znanja"],id:\.self){Text($0)}};TextField("Nastavna jedinica",text:$topic);TextField("Domaća zadaća",text:$homework);TextField("Napomena",text:$note)};Section{Button("Sačuvaj čas"){guard !topic.trimmingCharacters(in:.whitespaces).isEmpty else{store.message="Unesi nastavnu jedinicu.";return};store.addLesson(Lesson(date:Date.now.formatted(date:.numeric,time:.omitted),classroom:classroom,subject:subject,number:number,kind:kind,topic:topic,homework:homework,note:note,teacher:store.user));dismiss()}.frame(maxWidth:.infinity)}}.navigationTitle("Novi čas").navigationBarTitleDisplayMode(.inline)}
}
struct AddGradeView:View{
    @EnvironmentObject var store:EMISStore;@Environment(\.dismiss) var dismiss;@State private var studentID="U0001";@State private var subject="Matematika";@State private var grade=5
    var body:some View{Form{Section("Ocjena"){TextField("Korisničko ime učenika",text:$studentID).textInputAutocapitalization(.characters);Picker("Predmet",selection:$subject){ForEach(store.subjects,id:\.self){Text($0)}};Picker("Ocjena",selection:$grade){ForEach(1...5,id:\.self){Text("\($0)")}}};Button("Sačuvaj ocjenu"){guard store.data.students.contains(where:{$0.username==studentID})else{store.message="Učenik nije pronađen.";return};store.addGrade(studentID,subject,grade);dismiss()}}.navigationTitle("Nova ocjena")}
}
struct AddAbsenceView:View{
    @EnvironmentObject var store:EMISStore;@Environment(\.dismiss) var dismiss;@State private var studentID="U0001"
    var body:some View{Form{TextField("Korisničko ime učenika",text:$studentID).textInputAutocapitalization(.characters);Button("Evidentiraj izostanak"){guard store.data.students.contains(where:{$0.username==studentID})else{store.message="Učenik nije pronađen.";return};store.addAbsence(studentID);dismiss()}}.navigationTitle("Izostanak")}
}
struct AddCommentView:View{
    @EnvironmentObject var store:EMISStore;@Environment(\.dismiss) var dismiss;@State private var studentID="U0001";@State private var comment=""
    var body:some View{Form{TextField("Korisničko ime učenika",text:$studentID).textInputAutocapitalization(.characters);TextField("Komentar",text:$comment,axis:.vertical);Button("Sačuvaj komentar"){guard store.data.students.contains(where:{$0.username==studentID}),!comment.isEmpty else{store.message="Provjeri učenika i komentar.";return};store.addComment(studentID,comment);dismiss()}}.navigationTitle("Komentar")}
}
struct StudentDetailsView:View{
    @EnvironmentObject var store:EMISStore
    var body:some View{NavigationStack{List{if let s=store.currentStudent{Section("Lični podaci"){LabeledContent("Ime",value:s.name);LabeledContent("Odjeljenje",value:s.classroom);LabeledContent("Izostanci",value:"\(s.absences)")};Section("Ocjene"){ForEach(s.grades.keys.sorted(),id:\.self){subject in VStack(alignment:.leading){Text(subject).fontWeight(.semibold);Text((s.grades[subject] ?? []).map(String.init).joined(separator:", ")).foregroundStyle(.secondary)}}};Section("Komentari"){ForEach(Array(s.comments.enumerated()),id:\.offset){_,c in Text(c)}};Section{Button("Odjava",role:.destructive){store.logout()}}}}.navigationTitle("Moji podaci")}}
}
