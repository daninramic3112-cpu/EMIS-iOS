# EMIS iOS — SwiftUI početni projekat

Native iOS prototip prenesen iz postojeće Tkinter EMIS demonstracije. Uključuje prijavu nastavnika/učenika, 450 demo učenika u 18 odjeljenja, ocjene, izostanke, komentare i evidenciju časova. Podaci se trenutno čuvaju lokalno na iPhoneu u JSON datoteci.

## Demo prijava
- Nastavnik: `Danin` / `rsjebosna`
- Učenici: `U0001`–`U0450`, lozinka `skola123`

## Važno
Ovo je prototip, ne produkcioni školski sistem. Podaci se ne sinhronizuju između telefona. Lozinke su demo vrijednosti. Za stvarnu upotrebu potrebni su siguran serverski backend, hashiranje lozinki, kontrola pristupa, audit log, backup, HTTPS i odobrenje škole za obradu podataka učenika.

## Build
Otvori `EMIS/EMIS.xcodeproj` u Xcodeu ili poveži repozitorij sa Codemagicom. Za potpisani IPA potrebno je Apple signing podešavanje; za TestFlight/App Store Apple Developer Program.
